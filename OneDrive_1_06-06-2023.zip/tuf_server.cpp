#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <malloc.h>
#include <stdlib.h>
#include <sys/wait.h>

typedef struct sockaddr SOCKADDR;
typedef struct sockaddr_in SOCKADDR_IN;
void handler(int signum)
{
    if (signum == SIGCHLD)
    {
        int status = 0;
        pid_t pid;
        while ((pid = waitpid(-1, &status, WNOHANG)) > 0) 
        {
            printf("A child process (%d) has terminated\n", pid);
        }
    }
}
void process1()
{
    int s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    SOCKADDR_IN myaddr, saddr;
    int slen = sizeof(saddr);
    myaddr.sin_family = AF_INET;
    myaddr.sin_port = htons(6000);
    myaddr.sin_addr.s_addr = 0;
    bind(s, (SOCKADDR*)&myaddr, sizeof(myaddr));
    char buffer[1024];
    while (0 == 0)
    {
        memset(buffer, 0, sizeof(buffer));
        recvfrom(s, buffer, sizeof(buffer) - 1, 0, (SOCKADDR*)&saddr, (socklen_t*)&slen);
        if (buffer[strlen(buffer) - 1] == '\r' || 
            buffer[strlen(buffer) - 1] == '\n')
        {
            buffer[strlen(buffer) - 1] = 0;
        }
        FILE* f = fopen("users.db", "a+t");
        fprintf(f, "%s %s\n", buffer, inet_ntoa(saddr.sin_addr));
        fclose(f);
        saddr.sin_port = htons(6000);
        sendto(s, "ACK", 3, 0, (SOCKADDR*)&saddr, sizeof(saddr));
    }
}

void process2()
{
    int s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    SOCKADDR_IN myaddr, saddr;
    int slen = sizeof(saddr);
    myaddr.sin_family = AF_INET;
    myaddr.sin_port = htons(5000);
    myaddr.sin_addr.s_addr = 0;
    bind(s, (SOCKADDR*)&myaddr, sizeof(myaddr));
    listen(s, 10);
    while (0 == 0)
    {
        int c = accept(s, (SOCKADDR*)&saddr, (socklen_t*)&slen);
        FILE* f = fopen("users.db","rb");
        fseek(f, 0, SEEK_END);
        int size = ftell(f);
        fseek(f, 0, SEEK_SET);
        char* data = (char*)calloc(size + 1, 1);
        fread(data, 1, size, f);
        fclose(f);
        int sent = 0;
        while (sent < size)
        {
            int tmp = send(c, data + sent, size - sent, 0);
            if (tmp > 0)
            {
                sent += tmp;
            }else
                break;
        }
        free(data);
        data = NULL;
        close(c);
    }
}

int main()
{
    signal(SIGCHLD, handler);
    if (fork() == 0)
    { //Child process 1
        process1();
    }else
    {
        if (fork() == 0)
        { //Child process 2
            process2();
        }
    }
    getchar();
}